from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    peoples=[
        {'name':'Abhishek Gupta','age':14},
        {'name':'Rohan Sharma','age':26},
        {'name':'Vicky Kaushal','age':25},
        {'name':'Virat Kohli','age':35}
    ]
    return render(request,"index.html", context={'page':'Django 2024 ','people':peoples})

def contact(request):
   context = {'page':'Contact'}
   return render(request,"contact.html",context)

def about(request):
   context = {'page':'About'}
   return render(request,"about.html",context)

def success_page(request):
    return HttpResponse("<h1>Hey this is success Page</h1>")