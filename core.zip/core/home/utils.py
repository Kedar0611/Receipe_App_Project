from home.models import Student
import time

def run_this_function():
    print("function started")
    time.sleep(1)
    print("Function exicuted")